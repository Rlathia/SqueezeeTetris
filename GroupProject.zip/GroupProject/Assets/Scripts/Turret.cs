﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour {

	private Transform _transform;
	private Vector2 _currentPos;
	private float mousePosInBlocks;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		mousePosInBlocks = Input.mousePosition.x / Screen.width;
		//Debug.Log("mouse position :" + mousePosInBlocks);
		rotate_turretHead (mousePosInBlocks);
		
	}
	//rotation of Turret head
	void rotate_turretHead(float mousePosInBlocks){
			//turret rotates automatically with a specific speed
			_transform.Rotate(0, 0, 60 * Time.deltaTime);
	}
}
