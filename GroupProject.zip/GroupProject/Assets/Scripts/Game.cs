﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game : MonoBehaviour {

	public static int gridWidth = 10;
	public static int gridHeight = 16;
	public static Transform[,] grid = new Transform[gridWidth, gridHeight];

	public bool IsFullRowAt(int y){
		for (int x = 0; x < gridWidth; ++x) {
			if (grid [x, y] == null) {
				return false;
			}
		}
		return true;
	}
		
	public void DeleteBlockAt(int y){
		for (int x = 0; x < gridWidth; ++x) {
			Destroy (grid [x, y].gameObject);
			grid [x, y] = null;
		}
	}

	public void MoveRowDown(int y){
		for (int x = 0; x < gridWidth; ++x) {
			if (grid [x, y] != null) {
				grid [x, y - 1] = grid [x, y];
				grid [x, y] = null;
				grid [x, y - 1].position += new Vector3 (0, -1, 0);
			}
		}
	}

	public void MoveAllRowsDown(int y){
		for (int i= y; i < gridHeight; ++i) {
			MoveRowDown (i);
		}
	}

	public void DeleteRow(){
		for (int y = 0; y < gridHeight; ++y) {
			if(IsFullRowAt(y)){
				DeleteBlockAt(y);
				MoveAllRowsDown(y+1);
				--y;
			}
		}
	}

	public void UpdateGrid(Tetris t){
		//remove old tetris from game
		for(int y = 0; y < gridHeight; ++y){
			for(int x = 0; x < gridWidth; ++x){
				if(grid[x, y] != null){
					if(grid[x, y].parent == t.transform){
						grid[x, y] = null;
					}
				}
			}
		}
		foreach (Transform tetris in t.transform) {
			Vector2 position = Round (tetris.position);
			if (position.y < gridHeight && position.x < gridWidth) {
				grid [(int)position.x, (int)position.y] = tetris;
			}
		}
	}

	public Vector2 Round(Vector2 pos){
		return new Vector2 (Mathf.Round (pos.x), 
			Mathf.Round (pos.y));
	}

	public bool checkIsInsideGrid(Vector2 pos){
		return ((int)pos.x >= 0 && (int)pos.x < gridWidth && (int)pos.y > 0);
	}

	public Transform GetTransformAtGridPosition(Vector2 pos){
 		if(pos.y > gridHeight - 1){
			return null;
		}
		else{
			if ((int)pos.x < gridWidth && (int)pos.y < gridHeight) {
				Debug.Log ("get Transform at GRID position : " + (int)pos.x + "" + (int)pos.y);
				return grid [(int)pos.x, (int)pos.y];
			} else
				return null;

		}
	}

	public bool checkCanMoveRight(Vector2 pos){
		return ((int)pos.x < gridWidth && (int)pos.y > 0);
	}
	public bool checkCanMoveLeft(Vector2 pos){
		return ((int)pos.x >= 0 && (int)pos.y > 0);
	}
	public bool checkCanMoveDown(Vector2 pos){
		return (int)pos.y > 0;
	}
}