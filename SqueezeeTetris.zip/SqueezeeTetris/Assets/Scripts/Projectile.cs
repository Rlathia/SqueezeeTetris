﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class Projectile : MonoBehaviour {
	//private Transform _transform;
	//public Vector2 _currentSpeed;
	//public Vector2 _currentPosition;
	public float speed = 5;
	public Rigidbody2D body;

	void Start(){

		body = GetComponent<Rigidbody2D> ();

	//	_currentSpeed =new Vector2 (0,1);
	//
	//	_transform = gameObject.GetComponent<Transform> ();
	}

	//void Update(){
	//	_currentPosition = _transform.position;
	//	_currentPosition += _currentSpeed;
	//	_transform.position = _currentPosition;
	//}

	void FixedUpdate(){
		//make the target go to its destination
		body.AddForce(transform.right *speed);
	}
}