﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour {

	private Transform _transform;
	private Vector2 _currentPos;
	private float mousePosInBlocks;
	private float TurretSource;
	public GameObject Bullet;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		mousePosInBlocks = Input.mousePosition.x / Screen.width;
		rotate_turretHead (mousePosInBlocks);
		fire_turret (TurretSource);
	}

	//shoot the turret
	void fire_turret(float TurretSource){
		if (Input.GetKeyDown (KeyCode.Space)) {
			//fire the shot from all turrets
			GameObject clone = (GameObject)Instantiate (Bullet, transform.position, Quaternion.identity);
			clone.transform.localRotation = _transform.transform.localRotation;
			Destroy (clone, 6.0f);
		}
	}
		
	//rotation of Turret head
	void rotate_turretHead(float mousePosInBlocks){
		if (Input.GetKey (KeyCode.S)) {
			_transform.Rotate(0, 0, -70 * Time.deltaTime);
		}
		else if (Input.GetKey (KeyCode.W)) {
			_transform.Rotate(0, 0, 70 * Time.deltaTime);
		}
	}

	//destroy water bullet
	public void destroyBullet(){

		Destroy (this.gameObject);
	}

	public void OnTriggerEnter2D(Collider2D other){
		Debug.Log ("Collision");
		//checks if water Bullet collided with bomb,
		if(other.gameObject.tag.Equals("Bomb")){
			Debug.Log("Collision between Turret and Bomb");
			//Destroys bullet
			destroyBullet();

//-------------- add blast sound and explosion here----------------------------------//

			//Destroys and resets bomb
			FindObjectOfType<BombController>().Reset();
			//increases points/score
			FindObjectOfType<GameController>().gameOver();
		}
	}

}