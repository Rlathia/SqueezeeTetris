﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour {

	[SerializeField]
	private GameObject[] tetrisObjects;
	// Use this for initialization
	void Start () {
		spawnRandom ();
	}
	
	public void spawnRandom(){
		int index = Random.Range (0, tetrisObjects.Length);
		Instantiate (tetrisObjects [index], transform.position, Quaternion.identity);
	}
}
