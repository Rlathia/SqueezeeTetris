﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class Projectile : MonoBehaviour {
	//private Transform _transform;
	//public Vector2 _currentSpeed;
	//public Vector2 _currentPosition;
	public float speed = 3;
	public Rigidbody2D body;

	void Start(){

		body = GetComponent<Rigidbody2D> ();

	//	_currentSpeed =new Vector2 (0,1);
	//
	//	_transform = gameObject.GetComponent<Transform> ();
	}

	//void Update(){
	//	_currentPosition = _transform.position;
	//	_currentPosition += _currentSpeed;
	//	_transform.position = _currentPosition;
	//}

	void FixedUpdate(){
		//make the target go to its destination
		body.AddForce(transform.right *speed);
	}

	public void OnTriggerEnter2D(Collider2D other){
		Debug.Log ("Collision");
		if(other.gameObject.tag.Equals("Bomb")){
			Debug.Log("Collision with Bomb");
		}
	}
//	public void OnTriggerEnter2D(Collider2D other){
//		Debug.Log ("Collision");
//		//check if waterBullet collided with Bomb
//		if (other.gameObject.tag == "Bomb") {
//			Debug.Log ("studentID Collision with bomb\n");
//			other.gameObject.GetComponent<BombController> ().Reset ();//after collision with bomb, bomb disappears
//			//again points
//			//gameController.Score += 50;
//			//			if (_jeySound != null) {
//			//				_jeySound.Play ();
//			//			}
//		}
//	}
}