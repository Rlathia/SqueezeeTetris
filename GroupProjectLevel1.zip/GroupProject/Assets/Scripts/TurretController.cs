﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretController : MonoBehaviour {

	private Transform _transform;
	private Vector2 _currentPos;
	private float mousePosInBlocks;	
	private float turretSource = 0;
	public Rigidbody2D Bullet;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		//mousePosInBlocks = Input.mousePosition.x / Screen.width;
		//Debug.Log("mouse position :" + mousePosInBlocks);
		rotate_turretHead ();
		fire_turret (turretSource);
	}

	//shoot water from the turret
	void fire_turret(float turretSource){
		if (Input.GetKeyDown (KeyCode.Space)) {
			//shot water from all turrets
			Rigidbody2D clone = (Rigidbody2D)Instantiate (Bullet, transform.position, Quaternion.identity);
		}
		//Instantiate(fireball).GetComponent<Transform>().position = new Vector2(_currentPos.x + 30, _currentPos.y);
	}

	//rotation of Turret head
	void rotate_turretHead(){

		if (Input.GetKey (KeyCode.D)) {
			_transform.Rotate(0, 0, -70 * Time.deltaTime);
		}
		else if (Input.GetKey (KeyCode.A)) {
			_transform.Rotate(0, 0, 70 * Time.deltaTime);
		}
	}
}
