﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tetris : MonoBehaviour {

	float down = 0;
	public float downSpeed = 1;

	//private variables
	//private static Transform transform;
	//private static Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		//transform = gameObject.GetComponent<Transform> ();
		//_currentPos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		movement_userInput ();
	}
		
	void movement_userInput(){

		if (Input.GetKeyDown (KeyCode.RightArrow)) {
			//if right arrow is pressed, move 1 block right
			transform.position += new Vector3 (1, 0, 0);
			if (IsValidGridPosition ()) {
				FindObjectOfType<Game>().UpdateGrid (this);
			} else
				transform.position += new Vector3 (-1, 0, 0);
		} else if (Input.GetKeyDown (KeyCode.LeftArrow)) {
			//if left arrow is pressed, move 1 block left
			transform.position -= new Vector3 (1, 0, 0);
			if (IsValidGridPosition ()) {
				FindObjectOfType<Game>().UpdateGrid (this);
			} else
				transform.position -= new Vector3 (-1, 0, 0);
		} else if (Input.GetKeyDown (KeyCode.UpArrow)) {
			//if up arrow is pressed, rotate blocks by 90 degrees
			transform.Rotate (0, 0, 90);
			if (IsValidGridPosition ()) {
				FindObjectOfType<Game>().UpdateGrid (this);
			} else {
				Debug.Log ("Block has reached the end" + transform.position);
				transform.Rotate (0, 0, -90);
			}

		} else if (Input.GetKeyDown (KeyCode.DownArrow) || Time.time - down >= 1) {
			//if down arrow is pressed, move 1 block down
			transform.position -= new Vector3 (0, 1, 0);
			if (IsValidGridPosition ()) {
				FindObjectOfType<Game>().UpdateGrid (this);
			} else {
				transform.position -= new Vector3 (0, -1, 0);
				FindObjectOfType<Game> ().DeleteRow ();
				enabled = false;
				FindObjectOfType<Spawner> ().SpawnRandom ();
			}
			down = Time.time;
		}
	}

	bool IsValidGridPosition(){
		foreach (Transform tetris in transform) {
			Vector2 pos = FindObjectOfType<Game>().Round (tetris.position);
			if (FindObjectOfType<Game>().checkIsInsideGrid (pos)== false) {
				return false;
			}
			if (FindObjectOfType<Game>().GetTransformAtGridPosition(pos) != null && FindObjectOfType<Game>().GetTransformAtGridPosition(pos).parent != transform) {
				return false;
			}
		}
		return true; 
	}

	bool IsNotOnRightEnd(){
		foreach (Transform tetris in transform) {
			Vector2 pos = FindObjectOfType<Game>().Round (tetris.position);
			if (FindObjectOfType<Game>().checkCanMoveRight (pos) == false) {
				return false;
			}
			if (FindObjectOfType<Game>().GetTransformAtGridPosition(pos) != null && FindObjectOfType<Game>().GetTransformAtGridPosition(pos).parent != transform) {
				return false;
			}
		}
		return true; 
	}
	bool IsNotOnLeftEnd(){
		foreach (Transform tetris in transform) {
			Vector2 pos = FindObjectOfType<Game>().Round (tetris.position);
			if (FindObjectOfType<Game>().checkCanMoveLeft (pos) == false) {
				return false;
			}
			if (FindObjectOfType<Game>().GetTransformAtGridPosition(pos) != null && FindObjectOfType<Game>().GetTransformAtGridPosition(pos).parent != transform) {
				return false;
			}
		}
		return true; 
	}
	bool IsNotAtEnd(){
		foreach (Transform tetris in transform) {
			Vector2 pos = FindObjectOfType<Game>().Round (tetris.position);
			if (!FindObjectOfType<Game>().checkCanMoveDown (pos)) {
				return false;
			}
			if (FindObjectOfType<Game>().GetTransformAtGridPosition(pos) != null && FindObjectOfType<Game>().GetTransformAtGridPosition(pos).parent != transform) {
				return false;
			}
		}
		return true; 
	}
}