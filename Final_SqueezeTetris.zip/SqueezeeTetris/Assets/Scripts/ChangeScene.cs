﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour {

	public void ChangeToScene(int scene){
		SceneManager.LoadScene (scene);

	}

}
