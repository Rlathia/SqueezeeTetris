﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BadBlockCollision : MonoBehaviour {
	public AudioClip splash;

	// Use this for initialization
	void Start () {
		
	}

	void Reset(){
		Destroy (this.gameObject);
	}

	// if waterBullet collided with badBlock, then add points, destroy bad and destroy water bullet
	public void OnTriggerEnter2D(Collider2D other){
		Debug.Log ("Collision");
		if (other.gameObject.tag == "Water") {
			Debug.Log ("Collision of water bullet and bad block\n");
			//destroys bad(dirt) from the block
			this.Reset ();
			//play soun
			AudioSource.PlayClipAtPoint(splash, new Vector3(0, 0, 0));
			//Destroys water bullet
			Destroy (other.gameObject);
			//again points
			FindObjectOfType<GameController> ().Score += 50;
//			if (_jeySound != null) {
//				_jeySound.Play ();
//			}
		}
	}
}
