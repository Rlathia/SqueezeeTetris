﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

	[SerializeField]
	Text scoreLabel;
	[SerializeField]
	Text scoreValue;
	[SerializeField]
	Text gameoverLabel;
	[SerializeField]
	Text highscoreLabel;
	[SerializeField]
	Button playagainBtn;
	//level 2
	[SerializeField]
	Text levelLabel;
	[SerializeField]
	Button LeveltwoBtn;
	[SerializeField]
	GameObject bomb;

	public int _score  = 0;

	// Use this for initialization
	void Start () {
		//Player.Instance.gameCtrl = this;
		this.initialize ();
	}

	// Update is called once per frame
	void Update () {
		updateUI ();
	}

	public int Score {
		get{ return _score; }
		set {
			_score = value; 
			//gameCtrl.updateUI ();
			updateUI();
		}
	}
		
	public int Highscore {
		get{ return _score; }
		set {
			_score = value; 
			//gameCtrl.updateUI ();
			updateUI();
		}
	}


	//sets start of the game UI
	private void initialize(){
		Time.timeScale = 1;
		//Player.Instance.Score = 0;
		_score = 0;
		scoreLabel.gameObject.SetActive (true);
		scoreValue.gameObject.SetActive (true);
		gameoverLabel.gameObject.SetActive (false);
		highscoreLabel.gameObject.SetActive (false);
		playagainBtn.gameObject.SetActive (false);
	}

	//shows game over, high score and play again button
	//hides life and score label
	public void gameOver(){
		Time.timeScale = 0;
		//Player.Instance.Highscore = Player.Instance.Score;
		Highscore = Score;
		scoreLabel.gameObject.SetActive (false);
		scoreValue.gameObject.SetActive (false);
		gameoverLabel.gameObject.SetActive (true);
		highscoreLabel.gameObject.SetActive (true);
		playagainBtn.gameObject.SetActive (true);
		bomb.gameObject.SetActive (false);
	}

	//updates UI 
	public void updateUI(){
		scoreValue.text = "" + _score;
		highscoreLabel.text = "Your Score: " + _score;
	}

	// This method is called when play again button is clicked
	// Restarts the game
	public void playagainBtnClick(){
		SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
	}

	//when a row is full, increases the score by 100
	public void increaseFullRowScore(){
		//Player.Instance.Score += 100;
		_score += 100;
	}

	//will be used when start menu is implemented
	public void StartGame(){
		initialize ();
		SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
	}

	public void startLevelTwo(){
		Debug.Log ("button pressed");
		levelLabel.gameObject.SetActive (false);
		LeveltwoBtn.gameObject.SetActive (false);
		Time.timeScale = 1;
	}

	//when a bomb is destroyed, score increases by 50
	public void increaseScore(){
		_score += 50;
	}
}