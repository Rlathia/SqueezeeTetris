﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 * This scripts handles horizontal movement of the turret
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretController : MonoBehaviour {

	private Transform _transform;
	private Vector2 _currentPos;

	// Use this for initialization
	void Start () {
		_transform = gameObject.GetComponent<Transform> ();
		_currentPos = _transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		move_turret ();
	}

	// Horizontal movement of Turret
	void move_turret(){

		if (Input.GetKeyDown (KeyCode.A)) {
			Debug.Log ("A pressed");
			//if A is pressed, move 1 block right
				transform.position += new Vector3(-1, 0, 0);
			if (!checkBounds ()) {
				transform.position -= new Vector3(-1, 0, 0);
			}
		}
		else if (Input.GetKeyDown (KeyCode.D)) {
			Debug.Log ("D pressed");
			//if D arrow is pressed, move 1 block left
			transform.position += new Vector3(1, 0, 0);
			if (!checkBounds ()) {
				transform.position -= new Vector3(1, 0, 0);
			}
		}
	}

	//check bounds
	public bool checkBounds(){
		if (transform.position.x > 7.5 || transform.position.x < 0.5) {
			return false;
		} else {
			return true;
		}
	}
}