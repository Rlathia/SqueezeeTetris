﻿/* 
 * Name: Tanner Tugwell & Rajvi Lathia
 * Id: 100986114 & 101034808
 * Primary source : prof. Pawluk Labs
 * Secondary source : The Weekly Coder(Youtube Videos)
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombController : MonoBehaviour {

	/// PUBLIC INSTANCE VARIABLES
	[SerializeField]
	public float speed = 0.2f;
	[SerializeField]
	private float startY = 18.5f;
	[SerializeField]
	private float endY = -3;
	[SerializeField]
	private float startX = 0;
	[SerializeField]
	private float endX = 8.5f;
	public GameController gameCtrl;
	public AudioClip splash;

	//PRIVATE INSTANCE VARIABLES
	private Transform _transform;
	private Vector2 _currentPosition;

	// Use this for initialization
	void Start () {
		this._transform = gameObject.GetComponent<Transform> ();
		_currentPosition = _transform.position;
		this.Reset ();
	}

	// Update is called once per frame
	void Update () {
		_currentPosition = _transform.position;
		//move bomb down
		_currentPosition -= new Vector2 (0, speed);

		//check if we need to reset
		if (_currentPosition.y < endY) {
			//reset
			Reset ();
		}
		//apply changes
		_transform.position = _currentPosition;
	}

	//reset
	public void Reset() {		
		float x = Random.Range (startX, endX);
		float dy = Random.Range (0, 100);
		_currentPosition = new Vector2 (x, startY + dy);
		_transform.position = _currentPosition;
	}
		
	public void OnTriggerEnter2D(Collider2D other){
		Debug.Log ("Collision");
		//checks if water Bullet collided with bomb,
		if(other.gameObject.tag.Equals("Water")){
			Debug.Log("Collision with Water");
			//Destroys and resets bomb
			this.Reset ();
			AudioSource.PlayClipAtPoint(splash, new Vector3(0, 0, 0));
		
			//Destroys water bullet
			Turret.Destroy (other.gameObject);
			//increases points/score
			FindObjectOfType<GameController>().increaseScore ();
		}
	}
}